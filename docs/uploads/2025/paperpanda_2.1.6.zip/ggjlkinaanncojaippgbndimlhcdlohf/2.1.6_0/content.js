(function () {
    "use strict";
    let f = l();
    async function l() {
        return await chrome.runtime.sendMessage("get-config")
    }
    async function m() {
        document.location.hostname;
        var o = document.documentElement.innerHTML;
        function a(t, e) {
            if (!e || e === e) {
                var n = t.exec(o);
                if (n && n.length > 1)
                    return n[1]
            }
            return !1
        }
        function s() {
            var t,
            e = ["citation_doi", "doi", "dc.doi", "dc.identifier", "dc.identifier.doi", "bepress_citation_doi", "rft_id", "dcsext.wt_doi"],
            n = document.getElementsByTagName("meta");
            return Array.prototype.forEach.call(n, function (r) {
                if (r.name && !(e.indexOf(r.name.toLowerCase()) < 0) && !(r.scheme && r.scheme.toLowerCase() !== "doi")) {
                    var c = r.content.replace("doi:", "").replace(/https?:\/\/(www\.)?doi\.org\//i, "").trim();
                    c.indexOf("10.") === 0 && (t = c)
                }
            }),
            t ? (console.log("found a DOI from a meta tag: " + t), t) : null
        }
        async function i() {
            for (var t = (await f).p, e = 0; e < t.length; e++) {
                var n = t[e],
                r = a(new RegExp(n.regex), n.host);
                if (r)
                    return r
            }
            return null
        }
        async function d() {
            for (var t = [s, i], e = 0; e < t.length; e++) {
                var n = await t[e]();
                if (n)
                    return n
            }
            return null
        }
        var u = await d();
        return u
    }
    function g(o) {
        if (document.readyState !== "loading") {
            o();
            return
        }
        document.addEventListener("DOMContentLoaded", o)
    }
    function p(o) {
        return o.replace(/{[\w.]+}/, a => {
            const i = a.substr(1, a.length - 2).split(".").reduce((d, u) => d[u], window);
            return encodeURIComponent(i)
        })
    }
    const v = document.location + "";
    g(async() => {
        const o = (await f).s;
        function a() {
            for (const i of o)
                new RegExp(i.pattern, "gi").test(v) && [...document.querySelectorAll(i.selector)].filter(e => !e.hasAttribute("skip-element")).forEach(e => {
                    const n = e.style.display;
                    e.style.display = "none",
                    e.setAttribute("skip-element", !0),
                    fetch(p(i.url)).then(r => r.text()).then(r => {
                        const c = r.trim();
                        c && (e[i.attr] = c)
                    }).catch(() => {}).then(() => e.style.display = n)
                })
        }
        a(),
        new MutationObserver(() => a()).observe(document.body, {
            childList: !0,
            subtree: !0
        })
    }),
    chrome.runtime.onMessage.addListener((o, a, s) => {
        if (o === "get-doi")
            return m().then(i => s(i)), !0
    })
})();
