(function () {
    "use strict";
    const o = "https://getxmlppa.com/";
    async function i(n = !1) {
        const c = `${o}config.php?` + Date.now(), {
            config: t,
            configTimestamp: e
        } = await chrome.storage.local.get(["configTimestamp", "config"]);
        if (!n && Date.now() - (e || 0) < 3e5)
            return t;
        const a = await fetch(c).then(s => s.json());
        return chrome.storage.local.set({
            config: a,
            configTimestamp: Date.now()
        }),
        a
    }
    i(!0),
    chrome.runtime.onMessage.addListener((n, c, t) => {
        if (n === "get-config")
            return i().then(e => t(e)), !0
    }),
    chrome.runtime.onInstalled.addListener(function (n) {
        n.reason === "install" && fetch(`${o}install.php`)
    })
})();
