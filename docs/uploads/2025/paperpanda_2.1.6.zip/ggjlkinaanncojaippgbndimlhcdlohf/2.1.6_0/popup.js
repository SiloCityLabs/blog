import "./modulepreload-polyfill.js";
document.querySelectorAll("[data-locale]").forEach(e => {
    e.innerText = chrome.i18n.getMessage(e.dataset.locale)
});
chrome.storage.sync.get("showRating", function (e) {
    e.showRating == "false" || (document.getElementById("rating").style.display = "block")
});
function s(e) {
    return new Promise(t => {
        function n(o, a, i) {
            o === e && a.status === "complete" && (chrome.tabs.onUpdated.removeListener(n), t())
        }
        chrome.tabs.onUpdated.addListener(n)
    })
}
document.addEventListener("DOMContentLoaded", function () {
    var e = document.getElementById("fetchPaper");
    e.addEventListener("click", function () {
        chrome.tabs.query({
            active: !0,
            currentWindow: !0
        }, async t => {
            async function n() {
                const o = await chrome.tabs.sendMessage(t[0].id, "get-doi");
                o && chrome.storage.local.get("paperURL", function (a) {
                    var i = a.paperURL || "https://oa.mg/work/";
                    console.log("paperUrl: " + i),
                    chrome.tabs.create({
                        url: i + o
                    })
                })
            }
            try {
                await n()
            } catch {
                chrome.tabs.reload(t[0].id),
                await s(t[0].id),
                setTimeout(async() => {
                    await n()
                }, 1e3)
            }
        })
    }),
    document.getElementById("settings").addEventListener("click", function () {
        chrome.runtime.openOptionsPage()
    }),
    document.getElementById("rating-star-5").addEventListener("click", function () {
        chrome.tabs.create({
            url: "https://chrome.google.com/webstore/detail/paperpanda/ggjlkinaanncojaippgbndimlhcdlohf/reviews"
        }),
        chrome.storage.sync.set({
            showRating: "false"
        }, function () {}),
        document.getElementById("rating").style.display = "none"
    }),
    document.getElementById("rating-star-4").addEventListener("click", function () {
        setTimeout(function () {
            document.getElementById("rating-stars").style.display = "none"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating-thanks").style.display = "block"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating").style.display = "none"
        }, 500),
        chrome.storage.sync.set({
            showRating: "false"
        }, function () {})
    }),
    document.getElementById("rating-star-3").addEventListener("click", function () {
        setTimeout(function () {
            document.getElementById("rating-stars").style.display = "none"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating-thanks").style.display = "block"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating").style.display = "none"
        }, 500),
        chrome.storage.sync.set({
            showRating: "false"
        }, function () {})
    }),
    document.getElementById("rating-star-2").addEventListener("click", function () {
        setTimeout(function () {
            document.getElementById("rating-stars").style.display = "none"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating-thanks").style.display = "block"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating").style.display = "none"
        }, 500),
        chrome.storage.sync.set({
            showRating: "false"
        }, function () {})
    }),
    document.getElementById("rating-star-1").addEventListener("click", function () {
        setTimeout(function () {
            document.getElementById("rating-stars").style.display = "none"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating-thanks").style.display = "block"
        }, 100),
        setTimeout(function () {
            document.getElementById("rating").style.display = "none"
        }, 500),
        chrome.storage.sync.set({
            showRating: "false"
        }, function () {})
    })
});
