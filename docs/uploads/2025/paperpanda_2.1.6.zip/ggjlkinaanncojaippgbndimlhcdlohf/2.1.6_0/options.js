import "./modulepreload-polyfill.js";
document.querySelectorAll("[data-locale]").forEach(e => {
    e.innerText = chrome.i18n.getMessage(e.dataset.locale)
});
var l = document.getElementById("links");
l.addEventListener("click", function (e) {
    if (e.target.tagName === "BUTTON") {
        const t = e.target.getAttribute("data-link");
        document.getElementById("url").value = t,
        chrome.storage.local.set({
            paperURL: t
        })
    }
});
var a = document.getElementById("url");
chrome.storage.local.get("paperURL", function (e) {
    var t = e.paperURL;
    t && (a.value = t)
});
a.addEventListener("input", function () {
    var e = a.value;
    chrome.storage.local.set({
        paperURL: e
    })
});
